/*document.addEventListener("DOMContentLoaded", () => {
    let modal = document.getElementById("successModal");
    let addButton = document.querySelector(".recipe-add-btn");

    addButton.addEventListener("click", () => {
        modal.style.display = "block";
    });
});*/